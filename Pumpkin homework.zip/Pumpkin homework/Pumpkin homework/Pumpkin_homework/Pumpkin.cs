﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pumpkin_homework
{
    class Pumpkin
    {
        // Image representing the Projectile
        public Texture2D Texture;

        public Boolean rush;

        // Position of the Projectile relative to the upper left side of the screen
        public Vector2 Position;

        // State of the Projectile
        public bool Active;

        // The amount of damage the projectile can inflict to an enemy
        public int Damage;

        public int Value;

        public int Health;

        // Represents the viewable boundary of the game
        Viewport viewport;

        // Get the width of the projectile ship
        public int Width
        {
            get { return Texture.Width; }
        }

        // Get the height of the projectile ship
        public int Height
        {
            get { return Texture.Height; }
        }

        // Determines how fast the projectile moves
        public float projectileMoveSpeed;


        public void Initialize(Viewport viewport, Texture2D texture, Vector2 position)
        {
            Texture = texture;
            Position = position;
            this.viewport = viewport;

            Active = true;
            rush = false;
            Damage = 10;
            Health = 10;
            Value = 100;

            projectileMoveSpeed = .2f;
        }
        public void Update()
        {
            // Projectiles always move to the right
            Position.Y += projectileMoveSpeed;

            // Deactivate the bullet if it goes out of screen
            if (Position.Y + Texture.Height / 2 > viewport.Height || Health <= 0)
                Active = false;
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, Position, null, Color.White, 0f,
            new Vector2(Width / 2, Height / 2), 1f, SpriteEffects.None, 0f);
        }
    }
}