using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Pumpkin_homework
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D background;
        int xScreen;
        int yScreen;

        int timeSinceLastFrame = 0;
        int millisecondsPerFrame = 1000;


        Texture2D Pump1;
        Vector2 pos = Vector2.Zero;
        int xChange = 3;
        int yChange = 3;

        Texture2D Pump2;
        Vector2 pos2 = new Vector2(100,0);
        int xChange2 = 6;
        int yChange2 = 6;


        string welcome = "Welcome to Halloween World!";
        string oww = "Ouch!";
        SpriteFont display;
        Boolean touch = false;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            xScreen = graphics.PreferredBackBufferWidth;
            yScreen = graphics.PreferredBackBufferHeight;

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);


           background  = Content.Load<Texture2D>("hwbackground");
            Pump1 = Content.Load<Texture2D>("pumpkin1");
            Pump2 = Content.Load<Texture2D>("pumpkin2");
            display = Content.Load<SpriteFont>("SpriteFontTennis"); 
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here


            if (pos.Y >= (yScreen - Pump1.Height/5))
            {
                yChange = -yChange;
            }

            if (pos.Y < 0)
            {
                yChange = -yChange;
            }
            if (pos.X >= (xScreen - Pump1.Width/5))
            {
                xChange = -xChange;
            }
            if (pos.X < 0)
            {
                xChange = -xChange;
            }

            
            pos.X += xChange;
            pos.Y += yChange;
            
            if (pos2.Y >= (yScreen - Pump2.Height/10))
            {
                yChange2 = -yChange2;
            }

            if (pos2.Y < 0)
            {
                yChange2 = -yChange2;
            }
            if (pos2.X >= (xScreen - Pump2.Width/10))
            {
                xChange2 = -xChange2;
            }
            if (pos2.X < 0)
            {
                xChange2 = -xChange2;
            }


            pos2.X += xChange2;
            pos2.Y += yChange2;

            int x = (int)pos.X + (Pump1.Width / 5);
            int y = (int)pos.Y + (Pump1.Height / 5);

            if (x > pos2.X && x < pos2.X + Pump2.Width/10)
            {
                if (y > pos2.Y && y < pos2.Y + Pump2.Height/10)
                {
                    touch = true;
                }
            }

            timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
            if (timeSinceLastFrame > millisecondsPerFrame)
            {
                timeSinceLastFrame = 0;
                touch = false;
            }



                base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            spriteBatch.Draw(background, Vector2.Zero, Color.White);
            // spriteBatch.Draw(Pump1, Vector2.Zero, new Rectangle(0, 0, 0, 0), null, Color.White, 0.0f, new Vector2(Pump1.Width / 2, Pump1.Height / 2), 0.0f, SpriteEffects.None, 0.0f); 
            //spriteBatch.Draw(Pump1, Vector2.Zero, Color.White);
            spriteBatch.Draw(Pump1, pos, null, Color.White, 0.0f, Vector2.Zero, 0.2f, SpriteEffects.None, 0.0f);
            spriteBatch.Draw(Pump2, pos2, null, Color.White, 0.0f, Vector2.Zero, 0.1f, SpriteEffects.None, 0.0f);

            //spriteBatch.Draw(Pump2,
            //   pos2, null, Color.White, 0, new Vector2(Pump2.Width / 2, Pump2.Height / 2), 0.0f, SpriteEffects.None, 0.0f);
            // TODO: Add your drawing code here
            spriteBatch.DrawString(display, welcome, new Vector2(200,0), Color.Black);
           
            if (touch) {
                spriteBatch.DrawString(display, oww, new Vector2(300, 400), Color.Black);
              //  touch = false;
                    
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
